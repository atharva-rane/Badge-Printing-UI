import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";

import "../../../../../styles/volunteer/SevaAllocation.css";

const DropdownEditor = forwardRef((props, ref) => {
  const selectRef = useRef(null);

  const [value, setValue] = useState(props.value);

  useEffect(() => {
    if (selectRef.current) {
      selectRef.current.focus();
    }
  }, []);

  useImperativeHandle(ref, () => ({
    getValue() {
      return value;
    },

    afterGuiAttached() {
      if (selectRef.current) {
        selectRef.current.focus();
      }
    },

    isPopup() {
      return false;
    },
  }));

  return (
    <select
      ref={selectRef}
      value={value || ""}
      className="allocation-dropdown-editor"
      onChange={(e) => setValue(e.target.value)}
      onBlur={() => props.stopEditing()}
    >
      <option value="">-- Select --</option>

      {(props.values || []).map((item, index) => (
        <option key={index} value={item}>
          {item}
        </option>
      ))}
    </select>
  );
});

DropdownEditor.displayName = "DropdownEditor";

export default DropdownEditor;
